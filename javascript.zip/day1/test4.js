/* js에선 배열요소로 다양한 타입이 올수 있다.*/
/*배열 : 대괄호 , 객체 리터럴 : 중괄호 */
const arr = [1, '홍길동',4.5,true,[1,2],{name:'홍글동',age:10}];

const obj={
    attr1 : [1,2,3],
    attr2 : {name:'홍김동',age:11, hobby:['농구','축구']},
    attr3 : 1,
    attr4 : 3.14,
    attr5 : true,
    attr6 : arr
}



